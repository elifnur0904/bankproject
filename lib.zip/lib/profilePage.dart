import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
@override
  void initState() {
    // TODO: implement initState
    super.initState();
    print("USERID: "+FirebaseAuth.instance.currentUser!.uid);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profil Sayfası'),
        centerTitle: true,
      ),
      body: FutureBuilder<DocumentSnapshot>(
        future: _firestore.collection('userValues').doc(FirebaseAuth.instance.currentUser!.uid.toString()).get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Bir hata oluştu'));
          }
          if (!snapshot.hasData || !snapshot.data!.exists) {
            return Center(child: Text('Kullanıcı bilgisi bulunamadı'));
          }

          var userData = snapshot.data!;
          return ListView(
            children: [
              _buildProfileField(
                'Email',
                userData['userMail'],
                (newValue) => _updateField('userMail', newValue),
              ),
              _buildProfileField(
                'Ad Soyad',
                userData['userName'],
                (newValue) => _updateField('userName', newValue),
              ),
              _buildProfileField(
                'Telefon',
                userData['userPhone'],
                (newValue) => _updateField('userPhone', newValue),
              ),
              _buildProfileField(
                'T.C. NO',
                userData['userIDNumber'],
                (newValue) => _updateField('userIDNumber', newValue),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildProfileField(String label, String value, Function(String) onUpdate) {
    return ListTile(
      title: Text(label),
      subtitle: Text(value),
      trailing: IconButton(
        icon: Icon(Icons.edit),
        onPressed: () async {
          String? newValue = await _showEditDialog(label, value);
          if (newValue != null && newValue.isNotEmpty) {
            onUpdate(newValue);
          }
        },
      ),
    );
  }

  Future<String?> _showEditDialog(String label, String currentValue) async {
    TextEditingController controller = TextEditingController(text: currentValue);
    return showDialog<String>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Düzenle $label'),
          content: TextField(
            controller: controller,
            decoration: InputDecoration(hintText: 'Enter new $label'),
          ),
          actions: [
            TextButton(
              child: Text('İptal'),
              onPressed: () => Navigator.pop(context),
            ),
            TextButton(
              child: Text('Kaydet'),
              onPressed: () => Navigator.pop(context, controller.text),
            ),
          ],
        );
      },
    );
  }

  void _updateField(String fieldName, String newValue) {
    _firestore.collection('userValues').doc(FirebaseAuth.instance.currentUser!.uid).update({
      fieldName: newValue,
    }).then((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Başarıyla güncellendi')),
      );
      setState(() {}); 
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Hata: $error')),
      );
    });
  }
}
